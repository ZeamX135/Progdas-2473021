"""
Pertemuan 09
[PRAKTIKUM]  Program Gambaran sederhana tentang enkripsi, misalnya mengganti huruf a dengan j, b dengan k dan seterusnya

@author 2473021-Febrianus Leona Putra
@version 19 Oktober 2024
"""
plain_text = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
cipher_text = list("JKLMNOPQRSTUVWXYZABCDEFGHI")


message = input("Masukkan Kalimat: ")

