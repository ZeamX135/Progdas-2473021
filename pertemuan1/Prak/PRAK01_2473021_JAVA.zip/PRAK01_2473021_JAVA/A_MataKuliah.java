package pertemuan1.Prak.PRAK01_2473021_JAVA;

public class A_MataKuliah {
    public static void main(String[] args) {
        System.out.println("====================== Daftar Mata Kuliah =======================");
        System.out.println("       Kode     ||      Nama Mata Kuliah    ||     Hari, Jam   ");
        System.out.println("=================================================================");
        System.out.println("  SIB001202373  ||      Sistem Informasi    || Senin, 07.00-09.30");
        System.out.println("  SIB002202373  ||     Pemrograman Dasar    || Selasa, 15.30-17.30");
        System.out.println("  SIB003202373  ||  Enterprise Architecture || Rabu, 09.30-12.00");
        System.out.println("  SIB004202373  ||   Statistika Deskriptif  || Jumat, 07.00-09.30");

    }
}
