package pertemuan1.Prak.PRAK01_2473021_JAVA;

public class B_Fakultas {
    public static void main(String[] args) {
        System.out.println("|===============================================|");
        System.out.println("|                Daftar Fakultas                |");
        System.out.println("|===============================================|");
        System.out.println("|01. Fakultas Hukum dan Bisnis Digital          |");
        System.out.println("|02. Fakultas Teknologi dan Rekayasa Cerdas     |");
        System.out.println("|03. Fakultas Humaniora dan Industri Kreatif    |");
        System.out.println("|04. Fakultas Psikologi                         |");
        System.out.println("|05. Fakultas Kedokteran Gigi                   |");
        System.out.println("|06. Fakultas Kedokteran                        |");
        System.out.println("|===============================================|");
    }
}
