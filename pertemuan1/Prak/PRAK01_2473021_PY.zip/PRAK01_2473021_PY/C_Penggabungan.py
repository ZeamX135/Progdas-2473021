print("Penggabungan Kata")
pertama = str(input("Kata Pertama\t: "))
kedua = str(input("Kata Kedua\t: "))
print("Output\t\t:",pertama, kedua)