judul = " DAFTAR MATA KULIAH "
print (judul.center(72, '='))

print(f"{('         Kode').ljust(20)}||{('      Nama Mata Kuliah').ljust(27)}||     Hari, Jam")

print ("".center(72,'='))

print("    SIB001202373   ","||","    Sistem Informasi     ","||","Senin, 07.00-09.30")
print("    SIB002202373   ","||","   Pemrograman Dasar     ","||","Selasa, 15.30-17.30")
print("    SIB004202373   ","||"," Enterprise Architecture ","||","Rabu, 09.30-12.00")
print("    SIB003202373   ","||","  Statistika Deskriptif  ","||","Jumat, 07.00-09.30")

