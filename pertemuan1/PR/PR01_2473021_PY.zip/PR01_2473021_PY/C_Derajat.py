celcius = int(input("Input Celcius : "))
farenheit = (9/5*celcius)+32
reamur = 4/5*celcius

print()
print("Konversi",celcius,"derajat Celcius :")
print((int(farenheit)),"derajat Farenheit")
print((int(reamur)),"derajat Reamur")
