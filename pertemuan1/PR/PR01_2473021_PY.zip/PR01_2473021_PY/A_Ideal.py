print("Hitung berat badan ideal")
tb = int(input("Input Tinggi Badan : "))
ideal = (tb-100)-((tb-100)*15/100)
print("Berat Badan Ideal :",ideal,"kg")