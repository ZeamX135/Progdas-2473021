"""
Pertemuan 04
[PRAKTIKUM] program pembelian tiket museum yang menampilkan daftar museum per provinsinya

@author 2473021-Febrianus Leona Putra
@version 08 Oktober 2024
"""
nama = (input("Nama Pengguna: "))
print("======== APP MUSEUM ========")
print("1. Jakarta")
print("2. Jawa Barat")
print("3. Jawa Timur")
print("============================")