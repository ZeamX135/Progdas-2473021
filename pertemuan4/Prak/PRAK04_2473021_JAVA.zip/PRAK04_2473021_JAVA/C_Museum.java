/**
 * Pertemuan 04
 * [PRAKTIKUM] program pembelian tiket museum yang menampilkan daftar museum per provinsinya
 *
 * @author 2473021-Febrianus Leona Putra
 * @version 08 Oktober 2024
 */
package pertemuan4.Prak.PRAK04_2473021_JAVA;

import java.util.Scanner;

public class C_Museum {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nama Pengguna: ");
        String nama = sc.next();
        System.out.println("======== APP MUSEUM ========");
        System.out.println("1. Jakarta");
        System.out.println("2. Jawa Barat");
        System.out.println("3. Jawa Timur");
        System.out.println("============================");

        sc.close();

    }
}
